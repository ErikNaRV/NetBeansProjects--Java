/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package menu;

import java.util.Scanner;
import libreria.controladora.ControlAutor;
import libreria.controladora.ControlEditorial;
import libreria.controladora.ControlLibro;

/**
 *
 * @author Vane Proaño
 */
public class Menu {

    Scanner leer = new Scanner(System.in);
    ControlAutor controlautor = new ControlAutor();
    ControlLibro controlibro = new ControlLibro();

    //System.out.println("Ingrese el libro a eliminar");
    //String libroborrado = leer.nextLine();
    //controlibro.eliminarLibroSegundaParte(libroborrado);

    /* LibroJpaController libro = new LibroJpaController();
        libro.corregir();
        EditorialJpaController editorial = new EditorialJpaController();
        editorial.corregir();
        esto es un metodo para corregir el dato de alta que estaba en false y se le actualizo a true
     */
    //  System.out.println("Ingrese la editorial a buscar");
//                    String editorial = leer.nextLine();
//                    controleditorial.buscarEditorial(editorial);
    //
    ControlEditorial controleditorial = new ControlEditorial();

    //
    //
    public void menu() throws Exception {
        int op;
        do {
            System.out.println("|  1.- INSERT AUTHOR                              |");  //OK
            System.out.println("|  2.- INSERT EDITORIAL                           |");  //OK
            System.out.println("|  3.- INSERT BOOK                                |");  //OK
            System.out.println("|  4.- DELETE AUTHOR                              |");  //OK
            System.out.println("|  5.- DELETE EDITORIAL                           |");  //OK
            System.out.println("|  6.- DELETE BOOK                                |");  //OK
            System.out.println("|  7.- UPDATE AUTHOR                              |");  //OK
            System.out.println("|  8.- UPDATE EDITORIAL                           |");  //OK
            System.out.println("|  9.- UPDATE BOOK                                |");  //OK
            System.out.println("| 10.- SEARCH AN AUTHOR BY NAME                   |");  //OK
            System.out.println("| 11.- SEARCH A BOOK BY ISBN                      |");  //OK
            System.out.println("| 12.- SEARCH A BOOK BY TITLE                     |");  //OK
            System.out.println("| 13.- SEARCH BOOKS BY AUTHOR                     |");  //OK
            System.out.println("| 14.- SEARCH BOOKS BY EDITORIAL                  |");
            System.out.println("| 15.- SHOW BOOKS                                 |");
            System.out.println("| 16.- SHOW EDITORIALS                            |");  //OK
            System.out.println("| 17.- SHOW AUTHORS                               |");  //OK
            System.out.println("| 18.- EXIT                                       |");
            System.out.println("|-------------------------------------------------|");
            System.out.print("   SELECT AN OPTION : ");
            op=leer.nextInt();
            leer.nextLine();
            switch (op) {
                case 1:
                    System.out.println("Ingrese el nombre del autor:");
                    controlautor.crearAutor();
                    System.out.println("");
                    break;
                case 2:
                     System.out.println("Ingrese el nombre de la editorial:");
                    controleditorial.crearEditorial();
                    System.out.println("");
                    break;
                case 3:
                    controlibro.crearLibro();
                    System.out.println("");
                    break;
                case 4:
                    System.out.println("ingrese el nombre del autor que quiere eliminar");
                    String eliminado = leer.nextLine();
                    controlautor.eliminarAutor(eliminado);
                    System.out.println("");
                    break;
                case 5:
                    System.out.println("Ingrese la editorial que desea eliminar");
                    String eliminado1 = leer.nextLine();
                    controleditorial.eliminarEditorial(eliminado1);
                    System.out.println("");
                    break;
                case 6:
                    controlibro.eliminarLibro();
                    System.out.println("");
                    break;
                case 7:

                    System.out.println("Ingrese el autor a modificar");
                    String nombre = leer.nextLine();
                    controlautor.editarAutor(nombre);
                    System.out.println("");
                    break;
                case 8:
                    System.out.println("Ingrese la editorial a modificar");
                    String nombreE = leer.nextLine();
                    controleditorial.editarEditorial(nombreE);
                    System.out.println("");
                    break;

                case 9:
                    System.out.println("Ingrese el libro a modificar:");
                    String libronuevo= leer.nextLine();
                    controlibro.modificarLibro(libronuevo);
                    System.out.println("");
                    break;
                case 10:
                    System.out.println("Ingrese el autor del libro que desea encontrar");
                    String libroencontrado = leer.nextLine();
                    controlibro.buscarLibroporAutor(libroencontrado);
                    System.out.println("");
                    break;
                case 11:
                    System.out.println("ingrese el ISBN del libro");
                    Long codigo = leer.nextLong();
                    controlibro.buscarLibroporISBN(codigo);
                    System.out.println("");
                    break;
                case 12:
                    System.out.println("Ingrese el titulo a buscar");
                    String titulo = leer.nextLine();
                    controlibro.buscarLibroporTitulo(titulo);
                    System.out.println("");
                    break;
                case 13:
                    System.out.println("Ingrese el autor a buscar:");
                    String autor = leer.nextLine();
                    controlautor.buscarAutor(autor);
                    System.out.println("");
                    break;

                case 14:
                    System.out.println("Ingrese la editorial del libro a buscar");
                    String libroeditorial = leer.nextLine();
                    controlibro.buscarLibroporEditorial(libroeditorial);
                    System.out.println("");
                    break;
                case 15:
                    controlibro.mostrarLibros();
                    System.out.println("");
                    break;
                case 16:
                  controleditorial.mostrarEditorial();
                  System.out.println("");
                    break;
                case 17:
                    controlautor.mostrarAutor();
                    System.out.println("");
                    break;
                case 18:
                    System.out.println("Gracias por usar el sistema");
                    System.out.println("");
                    break;
                default:
                    System.out.println("opcion no valida");
                    System.out.println("");
                    
            }

        } while (op != 18);

    }
}
