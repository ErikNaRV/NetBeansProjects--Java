/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.controladora;

import java.util.List;
import java.util.Scanner;
import libreria.entidades.Autor;
import libreria.entidades.Editorial;
import libreria.entidades.Libro;
import libreria.persistencia.AutorJpaController1;
import libreria.persistencia.EditorialJpaController;
import libreria.persistencia.LibroJpaController;
import libreria.persistencia.exceptions.NonexistentEntityException;


/**
 *
 * @author Vane Proaño
 */
public class ControlLibro {

    LibroJpaController librojpa = new LibroJpaController(); // crear las tablas
    AutorJpaController1 autorjpa = new AutorJpaController1();
    EditorialJpaController editorialjpa = new EditorialJpaController();
    ControlAutor ca = new ControlAutor();
    ControlEditorial ce = new ControlEditorial();
     Scanner leer = new Scanner(System.in);

    public Libro crearLibro() {
        Libro libro = new Libro();
        boolean libroCreado = false;

        do {
            try {
                System.out.println("Ingrese el nombre del libro: ");
                String titulo = leer.nextLine().trim();

                System.out.println("Ingrese el año del libro: ");
                int anio = leer.nextInt();
                leer.nextLine(); // Consumimos la nueva línea después del nextInt()

                System.out.println("Ingrese el nombre del autor: ");
                Autor autor = ca.crearAutor();

                System.out.println("Ingrese el nombre de la editorial: ");
                Editorial editorial = ce.crearEditorial();

                if (datosDuplicados(titulo)) {
                    System.out.println("Titulo de libro existente");
                    continue;
                }

                if (titulo.isEmpty() || anio == 0 || autor == null || autor.getNombre().isEmpty()
                        || editorial == null || editorial.getNombre().isEmpty()) {
                    System.out.println("Error. Ingrese nuevamente.");
                    continue; // Vuelve al inicio del bucle sin continuar con la creación del libro
                }

                libro.setTitulo(titulo);
                libro.setAnio(anio);
                libro.setAutor(autor);
                libro.setEditorial(editorial);

                librojpa.create(libro);
                libroCreado = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } while (!libroCreado);

        return libro;
    }

    public void eliminarLibro() throws Exception {
        System.out.println("Ingrese el nombre del libro que va a eliminar: ");
        String titulo = leer.nextLine();

        System.out.println("Ingrese el año del libro que va a eliminar: ");
        int anio = leer.nextInt();
        leer.nextLine(); // Consumir el carácter de nueva línea

        System.out.println("Ingrese el nombre del autor del libro que va a eliminar (dejar en blanco si no hay autor): ");
        String nombreAutor = leer.nextLine();

        System.out.println("Ingrese el nombre de la editorial del libro que va a eliminar: ");
        String nombreEditorial = leer.nextLine();

        List<Libro> libros = librojpa.findLibroEntities();
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo) && libro.getAnio().equals(anio)
                    && (libro.getAutor() == null || libro.getAutor().getNombre().equalsIgnoreCase(nombreAutor))
                    && libro.getEditorial().getNombre().equalsIgnoreCase(nombreEditorial)) {
                librojpa.destroy(libro.getIsbn());
                System.out.println("Libro eliminado correctamente.");
                return; // Sale del método después de eliminar el libro
            }
        }

        System.out.println("No se encontró el libro especificado.");
    }

    public void eliminarLibroSegundaParte(String nombre) {
        List<Libro> libros = librojpa.findLibroEntities();

        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(nombre)) {
                try {
                    librojpa.destroy(libro.getIsbn());
                    System.out.println("Libro eliminado correctamente.");
                    return; // Sale del método después de eliminar el autor
                } catch (NonexistentEntityException e) {
                    System.out.println("Error al eliminar el libro: " + e.getMessage());
                    return; // Sale del método en caso de error
                }
            }
        }

        System.out.println("Libro no encontrado."); // Si no se encuentra el autor
    }

    public void buscarLibroporISBN(Long isbn) throws Exception {
        Libro libros = librojpa.findLibro(isbn);

        if (libros != null) {
            System.out.println("ISBN existentes:");

            System.out.println("ID: " + libros.getIsbn() + ", Nombre: " + libros.getTitulo());

        } else {
            System.out.println("No hay libros registrados en la base de datos.");
        }
    }

    public void buscarLibroporTitulo(String nombre) throws Exception {
        Libro libros = librojpa.findLibroN(nombre);

        if (libros != null) {
            System.out.println("titulos existentes:");

            System.out.println("ID: " + libros.getIsbn() + ", Nombre: " + libros.getTitulo());

        } else {
            System.out.println("No hay libros registrados en la base de datos.");
        }
    }

    public void buscarLibroporAutor(String nombre) throws Exception {
        List<Libro> libros = librojpa.findLibroEntities();

        for (Libro libro : libros) {
            if (libro.getAutor().getNombre().equalsIgnoreCase(nombre)) {
                System.out.println(libro.toString());
            }
        }

    }

    public void buscarLibroporEditorial(String nombre) throws Exception {
        List<Libro> libros = librojpa.findLibroEntities();

        for (Libro libro : libros) {
            if (libro.getEditorial().getNombre().equalsIgnoreCase(nombre)) {
                System.out.println(libro.toString());
            }
        }

    }

    public boolean datosDuplicados(String titulo) {
        List<Libro> libros = librojpa.findLibroEntities();
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                return true;
            }
        }
        return false;
    }

    public void modificarLibro(String titulo) throws Exception {
        Libro libros = librojpa.findLibroN(titulo);
        System.out.println("Elija la opcion");
        System.out.println("1. Nombre");
        System.out.println("2. Año");
        System.out.println("3. Editorial");
        System.out.println("4. Autor");
        int op = leer.nextInt();
        leer.nextLine();

        switch (op) {
            case 1:
                System.out.println("Ingrese el nuevo titulo");
                String nuevo = leer.nextLine();
                libros.setTitulo(nuevo);
                librojpa.edit(libros);
                System.out.println("Cambio exitoso");
                break;
            case 2:
                System.out.println("Ingrese el nuevo año");
                Integer nuevo2 = leer.nextInt();
                libros.setAnio(nuevo2);
                librojpa.edit(libros);
                System.out.println("Cambio exitoso");

                break;
  case 3:
    System.out.println("Ingrese el nuevo nombre de la editorial");
    String nuevo3 = leer.nextLine();

    // Verificar si la editorial ya existe en la base de datos
    Editorial editorialExistente = editorialjpa.findEditorialN(nuevo3);

    if (editorialExistente == null) {
        // Si la editorial no existe, asignamos directamente el nombre ingresado por el usuario al libro
        editorialExistente = new Editorial();
        editorialExistente.setNombre(nuevo3);
    }

    // Asignamos la editorial existente (o la nueva creada) al libro
    libros.setEditorial(editorialExistente);

    // Guardamos el libro con la nueva editorial en la base de datos
    librojpa.edit(libros);
    System.out.println("Cambio exitoso");
    break;


            case 4:
                autorjpa.findAutorEntities().toString();
                System.out.println("Ingrese el nuevo autor");
                String nuevo4 = leer.nextLine();
                libros.setAutor(autorjpa.findAutorN(nuevo4));
                librojpa.edit(libros);
                System.out.println("Cambio exitoso");

                break;
            default:
                throw new AssertionError();
        }

    }
    
public void mostrarLibros() {
    List<Libro> libros = librojpa.findLibroEntities();
    System.out.println("Libros encontrados en la base de datos:");
    System.out.println("");
    
    System.out.printf("%-5s | %-50s | %-10s | %-40s | %-30s%n",
            "ISBN", "Título", "Año", "Autor", "Editorial");
    System.out.println("-------------------------------------------------------------------------------------------------------------------------------------");
    
    for (Libro libro : libros) {
        System.out.printf("%-5d | %-50s | %-10d | %-40s | %-30s%n",
                libro.getIsbn(), libro.getTitulo(), libro.getAnio(),
                libro.getAutor().getNombre(), libro.getEditorial().getNombre());
    }
}



    }

