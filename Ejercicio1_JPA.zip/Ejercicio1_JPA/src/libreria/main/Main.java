/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package libreria.main;

import java.util.Scanner;
import libreria.controladora.ControlAutor;
import libreria.controladora.ControlEditorial;
import libreria.controladora.ControlLibro;
import libreria.persistencia.EditorialJpaController;
import libreria.persistencia.LibroJpaController;
import menu.Menu;

/**
 *
 * @author Vane Proaño
 */
public class Main {

    /**
     * @param args the command line arguments
        */
    public static void main(String[] args) throws Exception {
      Scanner leer = new Scanner(System.in);
//        ControlAutor ca = new ControlAutor();
        ControlLibro cl = new ControlLibro();
//        ControlEditorial ce = new ControlEditorial();
Menu m = new Menu();
m.menu();
        
       // System.out.println("ingrese el nombre del libro a modificar");
       // String cambio = leer.nextLine();
        //cl.modificarLibro(cambio);        
       // System.out.println("ingrese el nombre del libro a modificar");
       // String cambio = leer.nextLine();
        //cl.modificarLibro(cambio);
        //cl.mostrarLibros();
        
    }
}