/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import Entidad.Autor;

/**
 *
 * @author irina
 */
public class DAOAutor extends DAO<Autor>{
    //METODO INSERTAR AUTOR
    
    @Override
    public void guardar(Autor objeto) {
        super.guardar(objeto);
    }
    
   
    
    
}
