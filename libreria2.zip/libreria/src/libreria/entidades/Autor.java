
package libreria.entidades;

import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author lorena
 */
@Entity
public class Autor {
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    //Identity incrementa en 1 en 1
    //Auto genera claves de manera aleatoria
    //Sequence
    //Table
    private Integer id;
    
    @Basic
    private String nombre;
    private Boolean alta=true;
    
//    @Temporal(TemporalType.DATE)
//    //Date fecha
//    //Time hora
//    //TimeStamp fecha y hora
//    private Date fechaNacim;
    
    
    public Autor() {
         this.alta=true;//se coloca esta parte en el constructor vacio para que se cree con al atributo alta en true
    }

    public Autor(Integer id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Boolean getAlta() {
        return alta;
    }

    public void setAlta(Boolean alta) {
        this.alta = alta;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("\n"+"| %-10s | %-30s | %-10s | ", id, nombre, alta));
        sb.append("\n");
               
        return sb.toString();
    }
    
    
    
}
