package libreria.servicios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import libreria.entidades.Autor;
import libreria.persistencia.AutorDAO;

/**
 *
 * @author lorena
 */
public class AutorServicio {

    AutorDAO dao = new AutorDAO();
    Scanner leer = new Scanner(System.in);

    //METODO PARA INGRESAR UN NUEVO AUTOR
    public Autor crearAutor() throws Exception {

        List<Autor> autores = dao.mostrarAutores();
        boolean bandera = false;
        try {
            Autor autor = new Autor();
            System.out.println("Ingrese el nombre del autor");
            String nombre = leer.nextLine();
            for (Autor listaAutores : autores) {
                if (nombre.equalsIgnoreCase(listaAutores.getNombre())) {
                    System.out.println("El autor ya se encuentra en la base de datos");
                    bandera = true;

                }
            }
            if (!bandera) {

                autor.setNombre(nombre);
                dao.guardar(autor);
                System.out.println("El autor se ha ingresado correctamente");
                return autor;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
        return null;

    }

    //METODO PARA MOSTRAR TODOS LOS AUTORES
    public void mostrarAutores() throws Exception {

        System.out.println("");
        int[] longitud = {12, 30, 10};
        String[] encabezado = {"| ID", "Nombre", "Alta"};
        String titulo = "AUTORES";
        int anchoTotal = 60;
        int lado = (anchoTotal - titulo.length()) / 2;

        System.out.println("\n" + "-".repeat(anchoTotal));
        System.out.format("|%" + (lado - 1) + "s%s%" + (lado) + "s|", "", titulo, "");
        System.out.println("\n" + "-".repeat(anchoTotal));

        for (int i = 0; i < encabezado.length; i++) {
            System.out.format("%-" + longitud[i] + "s | ", encabezado[i]);
        }

        System.out.println("\n" + "-".repeat(anchoTotal));

        System.out.println(dao.mostrarAutores());

        System.out.println("\n" + "-".repeat(anchoTotal));

    }

    //METODO ELIMINAR A UN AUTOR
    public void eliminarAutor() throws Exception {
        System.out.println("Los autores registrados en la libreria son:");
        mostrarAutores();

        System.out.println("Ingrese el ID del autor que quiere eliminar");

        int id = leer.nextInt();
        dao.eliminar(id);

        System.out.println("El autor ha sido eliminado de nuestra base de datos");
    }

    //METODO PARA BUSCAR AUTOR POR NOMBRE
    public void buscarAutorNombre() throws Exception {

        try {
            System.out.println(" ");
            System.out.println("Ingrese el nombre del Autor ");
            String nombre = leer.nextLine();

            System.out.println("");
            int[] longitud = {22, 20, 20};
            String[] encabezado = {"| ID", "Nombre", "Alta"};
            String titulo = "AUTORES";
            int anchoTotal = 70;
            int lado = (anchoTotal - titulo.length()) / 2;

            System.out.println("\n" + "-".repeat(anchoTotal));
            System.out.format("|%" + (lado - 1) + "s%s%" + (lado) + "s|", "", titulo, "");
            System.out.println("\n" + "-".repeat(anchoTotal));

            for (int i = 0; i < encabezado.length; i++) {
                System.out.format("%-" + longitud[i] + "s | ", encabezado[i]);
            }

            System.out.println("\n" + "-".repeat(anchoTotal));
            System.out.println(dao.buscarAutorNombre(nombre));
            System.out.println("\n" + "-".repeat(anchoTotal));

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    //METODO PARA MODIFICAR AUTOR
    public void editarAutor() throws Exception {
        dao.modificarAutor();
    }

}
