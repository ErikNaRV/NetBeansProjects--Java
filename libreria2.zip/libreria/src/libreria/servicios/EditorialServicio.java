package libreria.servicios;

import java.util.List;
import java.util.Scanner;
import libreria.entidades.Autor;
import libreria.entidades.Editorial;
import libreria.persistencia.AutorDAO;
import libreria.persistencia.EditorialDAO;

/**
 *
 * @author lorena
 */
public class EditorialServicio {

    EditorialDAO dao = new EditorialDAO();
    Scanner leer = new Scanner(System.in);

     //METODO PARA INGRESAR NUEVA EDITORIAL
    public Editorial crearEditorial() throws Exception {

        List<Editorial> editoriales = dao.mostrarEditoriales();
        boolean bandera = false;
        try {
            Editorial editorial = new Editorial();
            System.out.println("Ingrese el nombre de la Editorial");
            String nombre = leer.nextLine();
            for (Editorial listaEditoriales : editoriales) {
                if (nombre.equalsIgnoreCase(listaEditoriales.getNombre())) {
                    System.out.println("La Editorial ya se encuentra en la base de datos");
                    bandera = true;

                }
            }
            if (!bandera) {

                editorial.setNombre(nombre);
                dao.guardar(editorial);
                System.out.println("La Editorial se ha ingresado correctamente");
                return editorial;
            }

        } catch (Exception e) {
            System.out.println(e.toString());

        }
        return null;

    }
    
     //METODO PARA MOSTRAR TODOS LAS EDITORIALES
    public void mostrarEditoriales() throws Exception {

        System.out.println("");
        int[] longitud = {12, 30, 10};
        String[] encabezado = {"| ID", "Nombre", "Alta"};
        String titulo = "EDITORIALES";
        int anchoTotal = 60;
        int lado = (anchoTotal - titulo.length()) / 2;

        System.out.println("\n" + "-".repeat(anchoTotal));
        System.out.format("|%" + (lado - 1) + "s%s%" + (lado) + "s|", "", titulo, "");
        System.out.println("\n" + "-".repeat(anchoTotal));

        for (int i = 0; i < encabezado.length; i++) {
            System.out.format("%-" + longitud[i] + "s | ", encabezado[i]);
        }

        System.out.println("\n" + "-".repeat(anchoTotal));

        System.out.println(dao.mostrarEditoriales());

        System.out.println("\n" + "-".repeat(anchoTotal));

    }

    //METODO ELIMINAR UNA EDITORIAL
    public void eliminarEditorial() throws Exception {
        try{
            System.out.println("Las Editoriales registradas en la libreria son:");
        mostrarEditoriales();

        System.out.println("Ingrese el ID de la Editorial que quiere eliminar");

        int id = leer.nextInt();
        dao.eliminar(id);

        System.out.println("La Editorial ha sido eliminada de nuestra base de datos");
        }catch(Exception e){
            System.out.println("La editorial no se ha podido edliminar" + e.getMessage());
        }
        
    }
    
    //METODO PARA MODIFICAR EDITORIAL
    public void editarEditorial() throws Exception{
        dao.modificarEditorial();
    }

}
