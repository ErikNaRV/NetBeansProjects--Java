package libreria.servicios;

import java.util.Scanner;
import libreria.persistencia.AutorDAO;
import libreria.persistencia.LibroDAO;

/**
 *
 * @author lorena
 */
public class Menu {

    Scanner leer = new Scanner(System.in);
    AutorServicio AS = new AutorServicio();
    EditorialServicio ES = new EditorialServicio();
    LibroServicio LS = new LibroServicio();
    LibroDAO dao=new LibroDAO();

    public void menuInicio() throws Exception {

        String inicio = "BIENVENIDOS A LIBRERIA EGG";
        String inicio2 = "Elija una opcion:";
        String inicio3 = "1-Autores";
        String inicio4 = "2-Libros";
        String inicio5 = "3-Editoriales";
        String inicio6 = "4-Salir";

        int opcion = 0;

        int anchoTotal = 50; //Es el ancho total del mensaje
        int frase = inicio.length();//Es la longitud del cartel de bienvenida (inicio)
        int lado = (anchoTotal - frase) / 2;//Es el ancho total del msj menos el de bienvenida/
//        int frase2 = inicio4.length();//Para calcular el espacio del msj mas largo de las opciones
        int frase2 = 3;//Es el margen para todos los mensajes

        System.out.println("*".repeat(anchoTotal));//Repite los caracteres tantas veces como el ancho
        System.out.format("*%" + (lado - 1) + "s%s%" + (lado - 1) + "s*", "", inicio, "");
        System.out.println("\n" + "*".repeat(anchoTotal));

        do {
            System.out.println("\n" + "-".repeat(anchoTotal));
            System.out.format("|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio2.length() - 1) + "s|", "", inicio2, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio3.length() - 1) + "s|", "", inicio3, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio4.length() - 1) + "s|", "", inicio4, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio5.length() - 1) + "s|", "", inicio5, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio6.length() - 1) + "s|", "", inicio6, "");

            System.out.println("\n" + "-".repeat(anchoTotal));
            //% hace referencia a los valores, s a los caracteres de letras

            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    menuAutores();
                    break;
                case 2:
                    menuLibros();
                    break;
                case 3:
                    menuEditoriales();
                    break;
                case 4:
                    System.out.println("Los esperamos nuevamente!!!");
                    break;
                default:
                    break;

            }
        } while (opcion != 4);
    }

    public void menuAutores() throws Exception {

        String inicio = "AUTORES";
        String inicio2 = "Elija una opcion:";
        String inicio3 = "1-Ingresar un nuevo Autor";
        String inicio4 = "2-Busqueda de un Autor por nombre";
        String inicio5 = "3-Mostrar todos los Autores";
        String inicio6 = "4-Eliminar a un Autor";
        String inicio7 = "5-Modificar informacion de un Autor";
        String inicio8 = "6-Salir";

        int opcion = 0;

        int anchoTotal = 50; //Es el ancho total del mensaje
        int frase = inicio.length();//Es la longitud del cartel de bienvenida (inicio)
        int lado = (anchoTotal - frase) / 2;//Es el ancho total del msj menos el de bienvenida/
//        int frase2 = inicio4.length();//Para calcular el espacio del msj mas largo de las opciones
        int frase2 = 3;//Es el margen para todos los mensajes

        System.out.println("*".repeat(anchoTotal));//Repite los caracteres tantas veces como el ancho
        System.out.format("*%" + (lado - 1) + "s%s%" + (lado - 1) + "s*", "", inicio, "");
        System.out.println("\n" + "*".repeat(anchoTotal));

        do {
            System.out.println("\n" + "-".repeat(anchoTotal));
            System.out.format("|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio2.length() - 1) + "s|", "", inicio2, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio3.length() - 1) + "s|", "", inicio3, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio4.length() - 1) + "s|", "", inicio4, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio5.length() - 1) + "s|", "", inicio5, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio6.length() - 1) + "s|", "", inicio6, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio7.length() - 1) + "s|", "", inicio7, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio8.length() - 1) + "s|", "", inicio8, "");

            System.out.println("\n" + "-".repeat(anchoTotal));
            //% hace referencia a los valores, s a los caracteres de letras

            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    AS.crearAutor();
                    break;
                case 2:
                    AS.buscarAutorNombre();
                    break;
                case 3:
                    AS.mostrarAutores();
                    break;
                case 4:
                    AS.eliminarAutor();
                    break;
                case 5:
                    AS.editarAutor();
                    break;
                case 6:
                    System.out.println("Volviendo al menu principal");
                default:
                    break;

            }
        } while (opcion != 6);

    }
//

    public void menuLibros() throws Exception {

        String inicio = "LIBROS";
        String inicio2 = "Elija una opcion:";
        String inicio3 = "1-Ingresar un nuevo libro";
        String inicio4 = "2-Mostrar todos los libros";
        String inicio5 = "3-Búsqueda de un libro por ISBN";
        String inicio6 = "4-Búsqueda de un libro por Título";
        String inicio7 = "5-Búsqueda de un libro por nombre del Autor";
        String inicio8 = "6-Búsqueda de un libro por nombre de Editorial";
        String inicio9 = "7-Eliminar un Libro";
        String inicio10 = "8-Modificar informacion de un Libro";
        String inicio11 = "9-Salir";

        int opcion = 0;

        int anchoTotal = 60; //Es el ancho total del mensaje
        int frase = inicio.length();//Es la longitud del cartel de bienvenida (inicio)
        int lado = (anchoTotal - frase) / 2;//Es el ancho total del msj menos el de bienvenida/
//        int frase2 = inicio4.length();//Para calcular el espacio del msj mas largo de las opciones
        int frase2 = 3;//Es el margen para todos los mensajes

        System.out.println("*".repeat(anchoTotal));//Repite los caracteres tantas veces como el ancho
        System.out.format("*%" + (lado - 1) + "s%s%" + (lado - 1) + "s*", "", inicio, "");
        System.out.println("\n" + "*".repeat(anchoTotal));

        do {
            System.out.println("\n" + "-".repeat(anchoTotal));
            System.out.format("|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio2.length() - 1) + "s|", "", inicio2, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio3.length() - 1) + "s|", "", inicio3, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio4.length() - 1) + "s|", "", inicio4, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio5.length() - 1) + "s|", "", inicio5, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio6.length() - 1) + "s|", "", inicio6, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio7.length() - 1) + "s|", "", inicio7, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio8.length() - 1) + "s|", "", inicio8, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio9.length() - 1) + "s|", "", inicio9, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio10.length() - 1) + "s|", "", inicio10, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio11.length() - 1) + "s|", "", inicio11, "");

            System.out.println("\n" + "-".repeat(anchoTotal));
            //% hace referencia a los valores, s a los caracteres de letras

            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    LS.crearLibro();
                    break;
                case 2:
                    LS.mostrarLibros();
//                    System.out.println(dao.mostrarLibros());
                    break;
                case 3:
                    LS.buscarISBN();
                    break;
                case 4:
                    LS.buscarTitulo();
                    break;
                case 5:
                    LS.buscarAutor();
                    break;
                case 6:
                    LS.buscarEditorial();
                    break;
                case 7:
                    LS.eliminarLibro();
                    break;
                case 8:
                    LS.editarLibro();
                    break;
                case 9:
                    System.out.println("Regresando el menu principal");
                    break;
                default:
                    break;

            }
        } while (opcion != 9);

    }
//

    public void menuEditoriales() throws Exception {

        String inicio = "EDITORIALES";
        String inicio1 = "Elija una opcion:";
        String inicio2 = "1-Ingresar una nueva Editorial";
        String inicio3 = "2-Mostrar todos las Editoriales";
        String inicio4 = "3-Eliminar una Editorial";
        String inicio5 = "4-Modificar informacion de una Editorial";
        String inicio6 = "5-Salir";

        int opcion = 0;

        int anchoTotal = 50; //Es el ancho total del mensaje
        int frase = inicio.length();//Es la longitud del cartel de bienvenida (inicio)
        int lado = (anchoTotal - frase) / 2;//Es el ancho total del msj menos el de bienvenida/
//        int frase2 = inicio4.length();//Para calcular el espacio del msj mas largo de las opciones
        int frase2 = 3;//Es el margen para todos los mensajes

        System.out.println("*".repeat(anchoTotal));//Repite los caracteres tantas veces como el ancho
        System.out.format("*%" + (lado - 1) + "s%s%" + (lado - 1) + "s*", "", inicio, "");
        System.out.println("\n" + "*".repeat(anchoTotal));

        do {
            System.out.println("\n" + "-".repeat(anchoTotal));
            System.out.format("|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio2.length() - 1) + "s|", "", inicio2, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio3.length() - 1) + "s|", "", inicio3, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio4.length() - 1) + "s|", "", inicio4, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio5.length() - 1) + "s|", "", inicio5, "");
            System.out.format("\n|%" + (frase2) + "s%s%" + (anchoTotal - frase2 - inicio6.length() - 1) + "s|", "", inicio6, "");

            System.out.println("\n" + "-".repeat(anchoTotal));
            //% hace referencia a los valores, s a los caracteres de letras

            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    ES.crearEditorial();
                    break;
                case 2:
                    ES.mostrarEditoriales();
                    break;
                case 3:
                    ES.eliminarEditorial();
                    break;
                case 4:
                    ES.editarEditorial();
                    break;
                case 5:
                    System.out.println("Retornando al menu principal");
                    break;
                default:
                    break;

            }
        } while (opcion != 5);

    }

}
