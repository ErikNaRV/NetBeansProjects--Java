package libreria.servicios;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import libreria.entidades.Autor;
import libreria.entidades.Editorial;
import libreria.entidades.Libro;
import libreria.persistencia.AutorDAO;
import libreria.persistencia.EditorialDAO;
import libreria.persistencia.LibroDAO;
import java.util.Iterator;

/**
 *
 * @author lorena
 */
public class LibroServicio {

    LibroDAO dao = new LibroDAO();
    AutorDAO AD = new AutorDAO();
    EditorialDAO ED = new EditorialDAO();
    Scanner leer = new Scanner(System.in);
    AutorServicio dao2 = new AutorServicio();
    EditorialServicio dao3 = new EditorialServicio();

    //METODO PARA INGRESAR UN NUEVO LIBRO
    public void crearLibro() throws Exception {

        Libro libro = new Libro();
        boolean i=false;
        do {
            try {
                System.out.println(" ");
                //Instancia los atributos isbn, año, titulo, ejemplares del libro
                //FALTA VERIFICAR Q NO SE REPITA EL RANDOM
                Long isbn = (long) (Math.random() * 1000);
                libro.setIsbn(isbn);
                leer.nextLine();
                System.out.println("Ingrese el titulo del Libro");
                String nuevoTitulo = leer.nextLine();
                libro.setTitulo(nuevoTitulo);
                System.out.println("Ingrese el año");
                libro.setAnio(leer.nextInt());
                System.out.println("Ingrese el total de ejemplares");
                libro.setEjemplares(leer.nextInt());
                System.out.println("Ingrese la cantidad de ejemplares prestados");
                libro.setEjemplaresPrestados(leer.nextInt());
                int ejemRestantes = libro.getEjemplares() - libro.getEjemplaresPrestados();
                libro.setEjemplaresRestantes(ejemRestantes);

                //Instancia el autor del libro, verificando si ya esta registrado o no
                System.out.println("Autor");
                leer.nextLine();
                System.out.println("Ingrese el nombre del Autor");
                String nombre = leer.nextLine();

                //verificar si ya esta el autor en la base de datos
                List<Autor> autores = AD.mostrarAutores();
                Iterator<Autor> listaAutores = autores.iterator();
                int a = 0;
                while (listaAutores.hasNext()) {

                    Autor ab = listaAutores.next();
                    if (ab.getNombre().equalsIgnoreCase(nombre)) {
//                    libro.setAutor(ab);
                        a++;
                    }
                }

                if (a > 0) {
                    libro.setAutor(AD.buscarAutorNombre(nombre));
                } else {
                    System.out.println("El Autor no se encuentra en nuestra base de datos. "
                            + "A continuacion cree un nuevo Autor");
                    Autor autor = dao2.crearAutor();
                    libro.setAutor(autor);
                    
                }

                // Instancia la editorial del libro, verificando si ya esta en la base de datos o no          
                System.out.println("Editorial");
                leer.nextLine();
                System.out.println("Ingrese el nombre de la Editorial");
                String nombre2 = leer.nextLine();

                //verificar editorial
                List<Editorial> editoriales = ED.mostrarEditoriales();
                Iterator<Editorial> listaEditoriales = editoriales.iterator();
                int b = 0;
                while (listaEditoriales.hasNext()) {

                    Editorial bc = listaEditoriales.next();
                    if (bc.getNombre().equalsIgnoreCase(nombre2)) {
//                    libro.setEditorial(bc);
                        b++;
                    }
                }

                if (b > 0) {
                    libro.setEditorial(ED.buscarEditorialNombre(nombre2));
                } else {
                    System.out.println("La Editorial no se encuentra en nuestra base de datos. "
                            + "A continuacion cree una nueva Editorial");
                    Editorial editorial = dao3.crearEditorial();
                    libro.setEditorial(editorial);
                }

                dao.guardar(libro);
                i=true;
                System.out.println("El libro se ha ingresado correctamente");

            } catch (Exception e) {
                System.out.println("El libro no se pudo guardar por: " + e.getMessage());
                System.out.println("Ingresar nuevamente la informacion");

            }
        } while (i==false);

    }

    //METODO PARA MOSTRAR TODOS LOS LIBROS
    public void mostrarLibros() throws Exception {

        System.out.println("");

        int[] longitud = {14, 40, 10, 30, 30};
        String[] encabezado = {"| ISBN", "Titulo", "Año", "Autor", "Editorial"};
        String titulo = "LIBROS";
        int anchoTotal = 138;
        int lado = (anchoTotal - titulo.length()) / 2;

        System.out.println("\n" + "-".repeat(anchoTotal));
        System.out.format("|%" + (lado - 1) + "s%s%" + (lado - 1) + "s|", "", titulo, "");
        System.out.println("\n" + "-".repeat(anchoTotal));

        for (int i = 0; i < encabezado.length; i++) {
            System.out.format("%-" + longitud[i] + "s | ", encabezado[i]);
        }

        System.out.println("\n" + "-".repeat(anchoTotal));

        dao.mostrarLibrosOK();

        System.out.println("\n" + "-".repeat(anchoTotal));

    }

    //METODO ELIMINAR UNA EDITORIAL
    public void eliminarLibro() throws Exception {
//        System.out.println("Las Editoriales registradas en la libreria son:");
//        mostrarEditoriales();

        System.out.println("Ingrese el ISBN del Libro que quiere eliminar");

        long id = leer.nextLong();
        dao.eliminar(id);

        System.out.println("El Libro ha sido eliminada de nuestra base de datos");
    }

    //METODO PARA BUSCAR LIBRO POR ISBN
    public void buscarISBN() throws Exception {

        try {

            System.out.println("Ingrese el numero de ISBN del Libro ");
            String isbn = leer.next();

            System.out.println("");
            int[] longitud = {42, 10, 30, 30};
            String[] encabezado = {"| Titulo", "Año", "Autor", "Editorial"};
            int anchoTotal = 123;

            System.out.println("\n" + "-".repeat(anchoTotal));

            for (int i = 0; i < encabezado.length; i++) {
                System.out.format("%-" + longitud[i] + "s | ", encabezado[i]);
            }
            System.out.println("\n" + "-".repeat(anchoTotal));

            System.out.println(String.format("| %-40s | %-10s | %-30s | %-30s |",
                    dao.buscarISBN(isbn).getTitulo(), dao.buscarISBN(isbn).getAnio(),
                    dao.buscarISBN(isbn).getAutor().getNombre(),
                    dao.buscarISBN(isbn).getEditorial().getNombre()));

            System.out.println("\n" + "-".repeat(anchoTotal));

        } catch (Exception e) {
            System.out.println("El libro no ha sido encontrado por: " + e.getMessage());
        }
    }

    //METODO PARA BUSCAR LIBRO POR TITULO
    public void buscarTitulo() throws Exception {

        try {

            System.out.println("Ingrese el titulo del Libro ");
            String titulo = leer.nextLine();

            System.out.println("");
            int[] longitud = {12, 10, 30, 30};
            String[] encabezado = {"| ISBN", "Año", "Autor", "Editorial"};
            int anchoTotal = 93;

            System.out.println("\n" + "-".repeat(anchoTotal));

            for (int i = 0; i < encabezado.length; i++) {
                System.out.format("%-" + longitud[i] + "s | ", encabezado[i]);
            }
            System.out.println("\n" + "-".repeat(anchoTotal));

            System.out.println(String.format("| %-10s | %-10s | %-30s | %-30s |",
                    dao.buscarTitulo(titulo).getIsbn(), dao.buscarTitulo(titulo).getAnio(),
                    dao.buscarTitulo(titulo).getAutor().getNombre(),
                    dao.buscarTitulo(titulo).getEditorial().getNombre()));

            System.out.println("\n" + "-".repeat(anchoTotal));

        } catch (Exception e) {
            System.out.println("El libro no ha sido encontrado por: " + e.getMessage());
        }
    }

    //METODO PARA BUSCAR LIBRO POR NOMBRE DEL AUTOR
    public void buscarAutor() throws Exception {

        try {

            System.out.println("Ingrese el nombre del Autor del Libro ");
            String nombre = leer.nextLine();

            System.out.println("");
            int[] longitud = {12, 40, 10, 30};
            String[] encabezado = {"| ISBN", "Titulo", "Año", "Editorial"};
            int anchoTotal = 103;

            System.out.println("\n" + "-".repeat(anchoTotal));

            for (int i = 0; i < encabezado.length; i++) {
                System.out.format("%-" + longitud[i] + "s | ", encabezado[i]);
            }
            System.out.println("\n" + "-".repeat(anchoTotal));

            List<Libro> libros = dao.buscarAutor(nombre);
            for (Libro libro : libros) {
                System.out.println(String.format("| %-10s | %-40s | %-10s | %-30s |",
                        libro.getIsbn(), libro.getTitulo(), libro.getAnio(),
                        libro.getEditorial().getNombre()));
            }
            System.out.println("\n" + "-".repeat(anchoTotal));

        } catch (Exception e) {
            System.out.println("El libro no ha sido encontrado por: " + e.getMessage());
        }
    }

    //METODO PARA BUSCAR LIBRO POR NOMBRE DE LA EDITORIAL
    public void buscarEditorial() throws Exception {

        try {

            System.out.println("Ingrese el nombre de la Editorial del Libro ");
            String nombre = leer.nextLine();

            System.out.println("");
            int[] longitud = {12, 40, 10, 30};
            String[] encabezado = {"| ISBN", "Titulo", "Año", "Autor"};
            int anchoTotal = 103;

            System.out.println("\n" + "-".repeat(anchoTotal));

            for (int i = 0; i < encabezado.length; i++) {
                System.out.format("%-" + longitud[i] + "s | ", encabezado[i]);
            }
            System.out.println("\n" + "-".repeat(anchoTotal));

            List<Libro> libros = dao.buscarEditorial(nombre);
            for (Libro libro : libros) {
                System.out.println(String.format("| %-10s | %-40s | %-10s | %-30s |",
                        libro.getIsbn(), libro.getTitulo(), libro.getAnio(), libro.getAutor().getNombre()));
            }
            System.out.println("\n" + "-".repeat(anchoTotal));

        } catch (Exception e) {
            System.out.println("El libro no ha sido encontrado por: " + e.getMessage());
        }
    }

    //METODO PARA MODIFICAR LIBRO
    public void editarLibro() throws Exception {
        dao.modificarLibro();
    }

}
