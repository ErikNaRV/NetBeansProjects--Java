package libreria;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import libreria.persistencia.AutorDAO;
import libreria.servicios.AutorServicio;
import libreria.servicios.EditorialServicio;
import libreria.servicios.LibroServicio;
import libreria.servicios.Menu;

/**
 *
 * @author lorena
 */
public class Libreria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {

        Menu menu = new Menu();
        menu.menuInicio();

    }

}
