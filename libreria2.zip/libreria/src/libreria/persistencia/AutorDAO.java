package libreria.persistencia;

import java.util.List;
import java.util.Scanner;
import javax.persistence.Basic;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import libreria.entidades.Autor;

public class AutorDAO extends DAO<Autor> {

    Scanner leer = new Scanner(System.in);

    //METODO GUARDAR AUTOR
    @Override
    public void guardar(Autor objeto) {
        super.guardar(objeto);
    }

    //METODO PARA MOSTRAR LOS AUTORES
    public List<Autor> mostrarAutores() throws Exception {

        try {
            //se conecta a la base de datos
            conectar();

            //pedimos todos los autores con un query
            List<Autor> autores = em.createQuery("SELECT m FROM Autor m ").getResultList();

            //nos desconectamos de la base de datos
            desconectar();

            //se devuelve la lista de autores
            return autores;
        } catch (Exception e) {
            throw new Exception("No es posible mostrar los autores por " + e.getMessage());

        }

    }

    //METODO ELIMINAR
    public void eliminar(int id) throws Exception {
        conectar();
        Autor autor = em.find(Autor.class, id);
        super.eliminar(autor);
    }

    //METODO PARA BUSCAR AUTOR POR NOMBRE
    public Autor buscarAutorNombre(String nombre) throws Exception {

        //se conecta a la base
        conectar();

        //hacemos una query
        Autor autor = (Autor) em.createQuery("SELECT m FROM Autor m WHERE m.nombre LIKE :nombre")
                .setParameter("nombre", nombre).getSingleResult();

        //nos desconectamos de la base
        desconectar();

        return autor;
    }

    //METODO PARA MODIFICAR AUTOR
    public void modificarAutor() throws Exception {

        try {
        System.out.println("Ingresar el nombre del Autor que quiere modificar");
        String nombre = leer.nextLine();

        Autor autor = buscarAutorNombre(nombre);

        List<Autor> autores = mostrarAutores();
        boolean bandera = false;
        
            System.out.println("Ingresar el nuevo nombre del Autor");
            String nombre2 = leer.nextLine();

            for (Autor listaAutores : autores) {
                if (nombre2.equalsIgnoreCase(listaAutores.getNombre())) {
                    System.out.println("El autor ya se encuentra en la base de datos");
                    bandera = true;

                }
            }
            if (!bandera) {

                autor.setNombre(nombre2);
                editar(autor);
                System.out.println("El autor se ha modificar correctamente");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

        }

    }
}

   