package libreria.persistencia;

import java.util.List;
import java.util.Scanner;
import libreria.entidades.Autor;
import libreria.entidades.Editorial;
import libreria.entidades.Libro;
import libreria.servicios.AutorServicio;
import libreria.servicios.EditorialServicio;

/**
 *
 * @author lorena
 */
public class LibroDAO extends DAO<Libro> {

    AutorDAO dao = new AutorDAO();
    EditorialDAO dao2 = new EditorialDAO();
    Scanner leer = new Scanner(System.in);
    AutorServicio AS = new AutorServicio();
    EditorialServicio ES = new EditorialServicio();

    //Metodo Insertar Autor
    @Override
    public void guardar(Libro libro) {
        super.guardar(libro);
    }

    //METODO PARA MOSTRAR LOS LIBROS
    public List<Libro> mostrarLibros() throws Exception {

        try {
            //se conecta a la base de datos
            conectar();

            //pedimos todos los autores con un query
            List<Libro> libros = em.createQuery("SELECT m FROM Libro m ").getResultList();
            //El resultado es una lista->getResultList

            //nos desconectamos de la base de datos
            desconectar();

            //se devuelve la lista de autores
            return libros;
        } catch (Exception e) {
            throw new Exception("No es posible mostrar los libros por " + e.getMessage());

        }

    }

    //METODO PARA MOSTRAR SOLAMENTE NOMBRE DE AUTOR Y EDITORIAL EN LOS LIBROS
    public void mostrarLibrosOK() throws Exception {
        List<Libro> libros = mostrarLibros();

        try {
            for (Libro libro : libros) {

                System.out.println(String.format("| %-12s | %-40s | %-10s | %-30s | %-30s |",
                        libro.getIsbn(), libro.getTitulo(), libro.getAnio(),
                        libro.getAutor().getNombre(), libro.getEditorial().getNombre()));

            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    //METODO ELIMINAR
    public void eliminar(Long isbn) throws Exception {
        conectar();
        Libro libro = em.find(Libro.class, isbn);
        super.eliminar(libro);
    }

    //METODO PARA BUSCAR LIBRO POR ISBN
    public Libro buscarISBN(String isbn) throws Exception {

        //se conecta a la base
        conectar();

        //hacemos una query
        Libro libro = (Libro) em.createQuery("SELECT m FROM Libro m WHERE m.isbn LIKE :isbn")
                .setParameter("isbn", isbn).getSingleResult();
        //El resultado es un objeto y no una lista->getSingleResult

        //nos desconectamos de la base
        desconectar();

        return libro;
    }

    //METODO PARA BUSCAR LIBRO POR TITULO
    public Libro buscarTitulo(String titulo) throws Exception {

        //se conecta a la base
        conectar();

        //hacemos una query
        Libro libro = (Libro) em.createQuery("SELECT m FROM Libro m WHERE m.titulo LIKE :titulo")
                .setParameter("titulo", titulo).getSingleResult();

        //nos desconectamos de la base
        desconectar();

        return libro;
    }

    //METODO PARA BUSCAR LIBRO POR NOMBRE DE AUTOR
    public List<Libro> buscarAutor(String nombre) throws Exception {

        //se conecta a la base
        conectar();

        //hacemos una query
        List<Libro> libros = em.createQuery("SELECT m FROM Libro m WHERE m.autor.nombre LIKE :nombre")
                .setParameter("nombre", nombre).getResultList();

        //nos desconectamos de la base
        desconectar();

        return libros;
    }

    //METODO PARA BUSCAR LIBRO POR NOMBRE DE EDITORIAL
    public List<Libro> buscarEditorial(String nombre) throws Exception {

        //se conecta a la base
        conectar();

        //hacemos una query
        List<Libro> libro = em.createQuery("SELECT m FROM Libro m WHERE m.editorial.nombre LIKE :nombre")
                .setParameter("nombre", nombre).getResultList();

        //nos desconectamos de la base
        desconectar();

        return libro;
    }

    //METODO PARA MODIFICAR LIBRO
    public void modificarLibro() throws Exception {

        try {
            
            System.out.println("Ingresar el ISBN del Libro que quiere modificar");
            String isbn = leer.next();

            Libro libro = buscarISBN(isbn);

            List<Libro> libros = mostrarLibros();
            boolean bandera = false;
            int opcion = 0;

            do {
                System.out.println(" ");
                System.out.println("Elegir la informacion que desea modificar del libro");
                System.out.println("1-Titulo");
                System.out.println("2-Año");
                System.out.println("3-Autor");
                System.out.println("4-Editorial");
                System.out.println("5-Ejemplares Totales");
                System.out.println("6-Ejemplares Prestados");
                System.out.println("7-Sin nada mas que editar del libro");

                opcion = leer.nextInt();

                switch (opcion) {
                    case 1:
                        //TITULO
                        leer.nextLine();
                        System.out.println("Ingrese el nuevo titulo del Libro");
                        String titulo = leer.nextLine();

                        for (Libro listaLibros : libros) {
                            if (titulo.equalsIgnoreCase(listaLibros.getTitulo())) {
                                System.out.println("El nuevo titulo ya se encuentra en la base de datos");
                                bandera = true;

                            }
                        }
                        if (!bandera) {

                            libro.setTitulo(titulo);
                            editar(libro);
                            System.out.println("El titulo del libro se ha modificado correctamente");
                        }
                        break;

                    case 2:
                        //AÑO
                        System.out.println("Ingrese el nuevo año del Libro");
                        int anio = leer.nextInt();

                        libro.setAnio(anio);
                        editar(libro);
                        System.out.println("El año del libro se ha modificado correctamente");
                        break;

                    case 3:
                        //AUTOR
                        leer.nextLine();
                        System.out.println("Ingrese el nuevo Autor del Libro");
                        String nombre = leer.nextLine();

                        for (Libro listaLibros : libros) {
                            if (listaLibros.getAutor().getNombre().equalsIgnoreCase(nombre)) {
                                bandera = true;
                                libro.setAutor(dao.buscarAutorNombre(nombre));
                                editar(libro);
                            }
                        }
                        if (!bandera) {
                            System.out.println("El Autor ingresado no figura en nuestra base de datos. Proceda a "
                                    + "crear el nuevo Autor ");
                            Autor autor = AS.crearAutor();
                            libro.setAutor(autor);
                            editar(libro);

                        }
                        System.out.println("El Autor del libro se ha modificado correctamente");
                        break;

                    case 4:
                        //EDITORIAL
                        int cd = 0;
                        leer.nextLine();
                        System.out.println("Ingrese el nombre de la nueva Editorial del Libro");
                        String nombre2 = leer.nextLine();

                        try {
                            for (Libro libro1 : libros) {
                                //para verificar que la editorial no este nula
                                if (libro1.getEditorial().getNombre().isEmpty() || libro1.getEditorial() == null) {
                                    cd++;
                                } else if (libro1.getEditorial().getNombre().equalsIgnoreCase(nombre2)) {
                                    //para guardar una editorial ya guardad en la base de datos
                                    libro.setEditorial(dao2.buscarEditorialNombre(nombre2));
                                    editar(libro);
                                    System.out.println("La Editorial del libro se ha modificado correctamente");
                                }

                            }

                            if (cd > 0) {
                                //crear nueva Editorial
                                System.out.println("La Editorial ingresada no se encuentra en nuestra base de datos. "
                                        + "Proceda a crear una nueva Editorial ");
                                Editorial editorial = ES.crearEditorial();
                                libro.setEditorial(editorial);
                                editar(libro);
                                System.out.println("La Editorial del libro se ha modificado correctamente");
                            }
                        } catch (Exception e) {
                            System.out.println("No se ha podido guardar la nueva Editorial por: " + e.getMessage());
                        }

                        //////
//                        for (Libro listaLibros : libros) {
//                            if (listaLibros.getEditorial().getNombre().equalsIgnoreCase(nombre2)) {
//                                bandera = true;
//                                libro.setEditorial(dao2.buscarEditorialNombre(nombre2));
//                                editar(libro);
//                            }
//                        }
//                         for (Libro listaLibros : libros) {
//                              if(listaLibros.getEditorial().equals(null)){
//                                  cd++;
//                              }
//                         }
//                         if (!bandera|| cd>0) {
//                            Editorial editorial= ES.crearEditorial();
//                            libro.setEditorial(editorial);
//                            editar(libro);
//                         }
                        break;

                    case 5:
                        //Metodo para ejemplares
                        break;
                    case 6:
                        //Metodo para ejemplares prestados
                        break;
                    case 7:
                        System.out.println("Regresando el menu principal");
                        break;
                    default:
                        break;

                }
            } while (opcion != 7);

            ///////////////
        } catch (Exception e) {
            System.out.println("No se ha podido modificarel libro por: " + e.getMessage());

        }

    }
}
