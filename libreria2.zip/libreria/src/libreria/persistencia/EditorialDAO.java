
package libreria.persistencia;

import java.util.List;
import java.util.Scanner;
import libreria.entidades.Autor;
import libreria.entidades.Editorial;

/**
 *
 * @author lorena
 */
public class EditorialDAO extends DAO<Editorial> {
    
    Scanner leer=new Scanner(System.in);
    
    //METODO INSERTAR EDITORIAL
    @Override
    public void guardar(Editorial editorial) {
        super.guardar(editorial); 
    }
    
    public List<Editorial> mostrarEditoriales() throws Exception {
        
    try{
        //se conecta a la base de datos
        conectar();
        
        //pedimos todos los autores con un query
        List<Editorial> editoriales = em.createQuery("SELECT m FROM Editorial m ").getResultList();
        
        //nos desconectamos de la base de datos
        desconectar();
        
        //se devuelve la lista de autores
        return editoriales;
    }catch(Exception e){
        throw new Exception("No es posible mostrar las editoriales por "+e.getMessage());
         
    }
    
    }
    
    //METODO ELIMINAR
    public void eliminar(int id) throws Exception {
        conectar();
        Editorial editorial = em.find(Editorial.class, id);
        super.eliminar(editorial);
    }
    
    //METODO PARA BUSCAR AUTOR POR NOMBRE
    public Editorial buscarEditorialNombre(String nombre) throws Exception {

        //se conecta a la base
        conectar();

        //hacemos una query
        Editorial editorial = (Editorial) em.createQuery("SELECT m FROM Editorial m WHERE m.nombre LIKE :nombre")
                .setParameter("nombre", nombre).getSingleResult();

        //nos desconectamos de la base
        desconectar();

        return editorial;
    }
    
    //METODO PARA MODIFICAR EDITORIAL
    public void modificarEditorial() throws Exception {

        try {
        System.out.println("Ingresar el nombre de la Editorial que quiere modificar");
        String nombre = leer.nextLine();

        Editorial editorial = buscarEditorialNombre(nombre);

        List<Editorial> editoriales = mostrarEditoriales();
        boolean bandera = false;
        
            System.out.println("Ingresar el nuevo nombre de la Editorial");
            String nombre2 = leer.nextLine();

            for (Editorial listaEditoriales : editoriales) {
                if (nombre2.equalsIgnoreCase(listaEditoriales.getNombre())) {
                    System.out.println("La Editorial ya se encuentra en la base de datos");
                    bandera = true;

                }
            }
            if (!bandera) {

                editorial.setNombre(nombre2);
                editar(editorial);
                System.out.println("La Editorial se ha modificado correctamente");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

        }

    }
}
